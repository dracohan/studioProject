package com.ryg.multidextest.ui;

/**
 * Created by renyugang on 15-5-27.
 */
public class View1 {
    int a;
    String b;
}
