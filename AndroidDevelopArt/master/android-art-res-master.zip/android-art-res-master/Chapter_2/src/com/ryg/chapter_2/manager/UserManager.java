package com.ryg.chapter_2.manager;

public class UserManager {

    public static int sUserId = 1;

}
